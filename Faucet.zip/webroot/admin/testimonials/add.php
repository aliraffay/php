<?php

 require_once (dirname(dirname(dirname(__FILE__))).'/functions.php');

 $fun->do_winfo('Testimonials');

 $fun->do_addtestimonial();

 show('Admin/Testimonial/add');

?>