<?php

 require_once ('loader.php');

 $fun->do_forgot_password();

 show('OAuth/forgot-password');

?>